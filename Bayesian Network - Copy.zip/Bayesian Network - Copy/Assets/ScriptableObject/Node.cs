using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

[CreateAssetMenu(fileName = "Node", menuName = "New Node", order = 1)]
public class Node : ScriptableObject
{
    public string nodeName;
    public int states = 2;

    public List<Node> parentNodes;
    public ProbTable conditionalProbTable;


    // P(query | evidence)

    public static float VariableElimination(Dictionary<Node, bool> query, Dictionary<Node, bool> evidence)
    {
        // remove any node that has nothing to do with the query nodes.
        List<Node> factors = new List<Node>();
        foreach(KeyValuePair<Node, bool> node_state_pair in query)
        {
            List<Node> node_net = GetAllRelatedNodes(node_state_pair.Key);
            factors.AddRange(node_net);
        }

        foreach(Node node in factors)
        {
            Debug.Log("factor: " + node.name);
        }


        // Determine which nodes are hidden (anything not in the query)

        List<Node> hiddenVariables = new List<Node>();

        foreach (Node node in factors)
        { 
            if(!evidence.ContainsKey(node) && !query.ContainsKey(node))
                hiddenVariables.Add(node);
        }

     

        // For all hidden variables v:
        // 1. remove all factors with v from factors 
        // 2. new_factor = join(all factors with v)
        // 3. new_factor = elim(new_factor, v)
        // 4. add new_factor to factors



        foreach (Node hiddenVariable in hiddenVariables)
        {
            
            Debug.Log("Hidden Node: " + hiddenVariable.name);

            HashSet<ProbTable> matchingFactors = new HashSet<ProbTable>();
            List<Node> factorsCopy = new List<Node>(factors);

            // 1. remove the hidden variables from factors
            RemoveHiddenVariables(factorsCopy, hiddenVariable, factors, matchingFactors, query);

            Debug.Log("Matching factors: ");
            foreach(ProbTable factor in matchingFactors)
            {
                factor.PrintProbTable();
            }

            // 2. Join the matching factors into a new factor
            ProbTable newFactor = new ProbTable();
            if(matchingFactors.Count > 1)
                newFactor = newFactor.Join(matchingFactors);
            else
                newFactor = matchingFactors.First();

            Debug.Log("Here is the new Factor after joining:");
            newFactor.PrintProbTable();

            // 3. eliminate the hidden varaible from the new factor table
            newFactor.EliminateHiddenVariable(hiddenVariable);
            Debug.Log("Here is the new Factor after elimination:");
            newFactor.PrintProbTable();

            // 4. add the new factor to factors
            Node newNode = new Node();
            newNode.conditionalProbTable = newFactor;
            factors.Add(newNode);

        }


        // Then, join all remaining factors and normalize

        HashSet<ProbTable> final_factors = new HashSet<ProbTable>();
        
        foreach(Node final_node in factors)
        {
            final_factors.Add(final_node.conditionalProbTable);
        }

        ProbTable final_factor_table = new ProbTable();
        if(final_factors.Count > 1)
        {
            final_factor_table = final_factor_table.Join(final_factors);
            final_factor_table.Normalize();
        }
        else
            final_factor_table = factors[0].conditionalProbTable;





        Debug.Log("Here is the final factor table:");
        final_factor_table.PrintProbTable();

        Dictionary<Node, bool> queryAnswer = new Dictionary<Node, bool>();
        queryAnswer.AddRange(evidence);
        queryAnswer.AddRange(query);

        foreach(KeyValuePair<SerializableDictionary<Node, bool>, float> keyValuePair in final_factor_table.probTable)
        {
            if (final_factor_table.AreDictionariesEqual(keyValuePair.Key, queryAnswer))
            {
                // keyValuePair.Key is equal to key
                return keyValuePair.Value;
            }
        }
        return 0.0f;
    }

    public static List<Node> GetAllRelatedNodes(Node node)
    {
        List<Node> relatedNodes = new List<Node>();
        relatedNodes.Add(node);

        foreach(Node parent in node.parentNodes)
        {
            if(parent != node && !relatedNodes.Contains(parent))
                relatedNodes.AddRange(GetAllRelatedNodes(parent));
        }

        return relatedNodes;
    }



    //Working
    private static void RemoveHiddenVariables(List<Node> factorsCopy, Node hidden_node, List<Node> factors, HashSet<ProbTable> matchingFactors, Dictionary<Node, bool> query)
    {

    

        foreach (Node currentNode in factorsCopy)
        {

            SerializableDictionary<Node, bool> first_dictionary_entry = currentNode.conditionalProbTable.probTable.First().Key;


            foreach(KeyValuePair<Node, bool> node_state_combination in first_dictionary_entry)
            {

                if(node_state_combination.Key != hidden_node)
                {
                    matchingFactors.Add(currentNode.conditionalProbTable);
                    factors.Remove(currentNode);
                }

                if(node_state_combination.Key.parentNodes != null)
                {
                    foreach (Node parentNode in node_state_combination.Key.parentNodes)
                    {
                        if (parentNode != hidden_node)
                        {
                            matchingFactors.Add(currentNode.conditionalProbTable);
                            factors.Remove(currentNode);
                        }
                    }
                }

               

            }
        }
    }



}




