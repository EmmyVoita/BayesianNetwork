using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

[CustomEditor(typeof(Bayesian))]
public class BayesianEditor : Editor
{
    private Node node;
    private int selectionIndex;

    public override void OnInspectorGUI()
    {
        // Draw the default inspector
        DrawDefaultInspector();

        // Get the target Node
        Bayesian bayesian = (Bayesian)target;
        if (bayesian == null) return;







        EditorGUILayout.LabelField("Add to Query and Evidence Dictionaries");

        using (var horizontalScope = new EditorGUILayout.HorizontalScope())
        {
            // Display an object field for the Node
            node = (Node)EditorGUILayout.ObjectField("Node", node, typeof(Node), true);

            // Display a dropdown for the selection
            string[] options = new string[] { "False", "True" };
            selectionIndex = EditorGUILayout.Popup(selectionIndex, options, GUILayout.Width(70f));
        }

        if (EditorGUI.EndChangeCheck())
        {
            EditorUtility.SetDirty(bayesian);
        }

        if (GUILayout.Button("Add To Evidence"))
        {
            bool boolValue = (selectionIndex == 1); // convert selection index to bool
            bayesian.evidence.Add(node, boolValue);
        }
        if (GUILayout.Button("Clear Evidence"))
        {
            bayesian.evidence.Clear();
        }
        if (GUILayout.Button("Add To Query"))
        {
            bool boolValue = (selectionIndex == 1); // convert selection index to bool
            bayesian.query.Add(node, boolValue);
        }
        if (GUILayout.Button("Clear Query"))
        {
            bayesian.query.Clear();
        }    
    }
}


