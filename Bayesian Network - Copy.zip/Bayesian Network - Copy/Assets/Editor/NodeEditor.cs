using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

[CustomEditor(typeof(Node))]
public class NodeEditor : Editor
{

    public override void OnInspectorGUI()
    {
        // Draw the default inspector
        DrawDefaultInspector();

        // Get the target Node
        Node node = (Node)target;
        if (node == null) return;

        // Show the conditional probability table
        //EditorGUILayout.LabelField("Conditional Probability Table");

        if (GUILayout.Button("Create Table"))
        {
            // Create a new instance of ProbTable and assign it to the node's conditionalProbTable property
            if (!node.parentNodes.Contains(node))
            {
                node.parentNodes.Add(node);
            }
            node.conditionalProbTable = new ProbTable(node.parentNodes);

        }

        if (GUILayout.Button("Print Table"))
        {
            node.conditionalProbTable.PrintProbTable();

        }

        if (EditorGUI.EndChangeCheck())
        {
            EditorUtility.SetDirty(node);
        }

        /*using (var horizontalScope = new EditorGUILayout.HorizontalScope())
        {
            SerializableDictionary<Node, bool> newKey = new SerializableDictionary<Node, bool>();
            float newValue = 0f;

            // Display the keys of the inner dictionary
            foreach (Node mynode in node.parentNodes)
            {
                string label = mynode.nodeName;
                EditorGUILayout.LabelField(label, GUILayout.Width(30f));
                bool boolValue = EditorGUILayout.Toggle(false, GUILayout.Width(30f));
                newKey.Add(mynode, boolValue);
            }

            // Display the value of the outer dictionary
            string value = EditorGUILayout.TextField("0", GUILayout.Width(100f));
            if (float.TryParse(value, out newValue))
            {
            }

            if (GUILayout.Button("Add Entry"))
            {
                if (!node.conditionalProbTable.probTable.ContainsKey(newKey))
                {
                    node.conditionalProbTable.probTable.Add(newKey, newValue);
                }
                else
                {
                    Debug.LogWarning("Key already exists in dictionary.");
                }
            }
            
        }*/
    }
}




